package com.fortune.fortune.repository;

import com.fortune.fortune.entity.UserFortune;
import com.fortune.fortune.entity.ZodiacSign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserFortuneRepository extends JpaRepository<UserFortune, Long> {

    // 특정 사용자의 운세 조회 기록
    List<UserFortune> findByUserNameOrderByCreatedAtDesc(String userName);

    // 특정 생년월일의 운세 조회 기록
    List<UserFortune> findByBirthDateOrderByCreatedAtDesc(LocalDate birthDate);

    // 별자리별 조회 횟수
    @Query("SELECT COUNT(uf) FROM UserFortune uf WHERE uf.zodiacSign = :zodiacSign")
    Long countByZodiacSign(@Param("zodiacSign") ZodiacSign zodiacSign);
}