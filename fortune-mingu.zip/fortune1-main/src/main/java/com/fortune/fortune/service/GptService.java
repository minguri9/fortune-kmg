package com.fortune.fortune.service;

import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;
import com.theokanning.openai.service.OpenAiService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.time.Duration;

import java.util.List;

@Service
public class GptService {

    private OpenAiService openAiService;
    private final String apiKey;

    public GptService(@Value("${openai.api-key}") String apiKey) {
        this.apiKey = apiKey;
        if (apiKey != null && !apiKey.isBlank() && !apiKey.equals("YOUR_OPENAI_API_KEY_HERE")) {
            try {
                // Add a timeout to prevent long waits
                this.openAiService = new OpenAiService(apiKey, Duration.ofSeconds(30));
            } catch (Exception e) {
                System.err.println("### Failed to initialize OpenAiService. AI features will be disabled. Check your API key. Error: " + e.getMessage());
                this.openAiService = null;
            }
        } else {
            System.err.println("### OpenAI API key is not set or is a placeholder. AI features will be disabled.");
            this.openAiService = null;
        }
    }

    /**
     * Takes a simple fortune text and asks the AI for a more detailed interpretation.
     * @param fortuneText The existing fortune text.
     * @return An AI-generated commentary on the fortune.
     */
    public String getAiCommentary(String fortuneText) {
        if (openAiService == null) {
            return "AI 해설 기능이 설정되지 않았습니다. API 키를 확인해주세요.";
        }
        
        String prompt = String.format(
                "너는 세계 최고의 운세 해설가이다. 다음 운세 문장에 대해 더욱 깊이 있고 자세한 해설을 1~2문장으로 추가해줘.\n\n운세: \"%s\"",
                fortuneText
        );

        try {
            ChatCompletionRequest completionRequest = ChatCompletionRequest.builder()
                    .model("gpt-4o-mini")
                    .messages(List.of(
                            new ChatMessage("system", "너는 운세 해설가이다."),
                            new ChatMessage("user", prompt)
                    ))
                    .maxTokens(150)
                    .temperature(0.7)
                    .build();

            return openAiService.createChatCompletion(completionRequest)
                    .getChoices().get(0).getMessage().getContent();
        } catch (Exception e) {
            System.err.println("Error calling OpenAI API: " + e.getMessage());
            return "AI 해설을 가져오는 데 실패했습니다.";
        }
    }

    public String generateGptFortuneForPeriod(String period, String userName, com.fortune.fortune.entity.ZodiacSign zodiacSign) {
        if (openAiService == null) {
            return "AI 운세 생성 기능이 설정되지 않았습니다. API 키를 확인해주세요.";
        }

        String prompt = String.format(
            "당신은 매우 유능한 운세 전문가입니다. 아래 정보를 바탕으로 '%s'의 운세를 생성해주세요. 운세 내용은 2~3문장으로 요약하고, 반드시 한글로 작성해주세요.\n\n- 이름: %s\n- 별자리: %s",
            period, userName, zodiacSign.getKoreanName()
        );

        try {
            ChatCompletionRequest completionRequest = ChatCompletionRequest.builder()
                    .model("gpt-4o-mini")
                    .messages(List.of(
                            new ChatMessage("system", "너는 운세 전문가이며, 요청받은 기간에 맞춰 운세를 생성한다."),
                            new ChatMessage("user", prompt)
                    ))
                    .maxTokens(200)
                    .temperature(0.8)
                    .build();

            return openAiService.createChatCompletion(completionRequest)
                    .getChoices().get(0).getMessage().getContent();
        } catch (Exception e) {
            System.err.println("Error calling OpenAI API for " + period + " fortune: " + e.getMessage());
            return period + "의 운세를 생성하는 데 실패했습니다.";
        }
    }
}
