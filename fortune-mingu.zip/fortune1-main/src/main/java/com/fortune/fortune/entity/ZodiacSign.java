package com.fortune.fortune.entity;

import lombok.Getter;

@Getter
public enum ZodiacSign {
    ARIES("양자리", "3월 21일 ~ 4월 19일", "열정적이고 용감하며, 새로운 도전을 두려워하지 않는 리더입니다.", 3, 21, 4, 19),
    TAURUS("황소자리", "4월 20일 ~ 5월 20일", "현실적이고 안정적인 것을 추구하며, 인내심이 강하고 신뢰할 수 있습니다.", 4, 20, 5, 20),
    GEMINI("쌍둥이자리", "5월 21일 ~ 6월 21일", "호기심이 많고 사교적이며, 다양한 분야에 재능을 보이는 재치 있는 사람입니다.", 5, 21, 6, 21),
    CANCER("게자리", "6월 22일 ~ 7월 22일", "감정이 풍부하고 동정심이 많으며, 가족과 친구를 소중히 여깁니다.", 6, 22, 7, 22),
    LEO("사자자리", "7월 23일 ~ 8월 22일", "자신감이 넘치고 카리스마 있으며, 사람들의 중심에 서기를 좋아합니다.", 7, 23, 8, 22),
    VIRGO("처녀자리", "8월 23일 ~ 9월 22일", "꼼꼼하고 분석적이며, 완벽을 추구하는 성실한 성격의 소유자입니다.", 8, 23, 9, 22),
    LIBRA("천칭자리", "9월 23일 ~ 10월 22일", "균형과 조화를 중시하며, 사교적이고 공정한 판단력을 가지고 있습니다.", 9, 23, 10, 22),
    SCORPIO("전갈자리", "10월 23일 ~ 11월 21일", "강한 직관력과 통찰력을 지녔으며, 목표를 향한 열정과 집중력이 뛰어납니다.", 10, 23, 11, 21),
    SAGITTARIUS("사수자리", "11월 22일 ~ 12월 21일", "자유롭고 낙천적이며, 새로운 모험과 철학적인 탐구를 즐깁니다.", 11, 22, 12, 21),
    CAPRICORN("염소자리", "12월 22일 ~ 1월 19일", "책임감이 강하고 현실적이며, 인내심을 가지고 목표를 향해 나아갑니다.", 12, 22, 1, 19),
    AQUARIUS("물병자리", "1월 20일 ~ 2월 18일", "독창적이고 인도주의적이며, 고정관념에 얽매이지 않는 자유로운 영혼입니다.", 1, 20, 2, 18),
    PISCES("물고기자리", "2월 19일 ~ 3월 20일", "공감 능력이 뛰어나고 예술적 감각이 있으며, 상상력이 풍부하고 낭만적입니다.", 2, 19, 3, 20);

    private final String koreanName;
    private final String period;
    private final String description;
    private final int startMonth;
    private final int startDay;
    private final int endMonth;
    private final int endDay;

    ZodiacSign(String koreanName, String period, String description, int startMonth, int startDay, int endMonth, int endDay) {
        this.koreanName = koreanName;
        this.period = period;
        this.description = description;
        this.startMonth = startMonth;
        this.startDay = startDay;
        this.endMonth = endMonth;
        this.endDay = endDay;
    }

    public static ZodiacSign fromBirthDate(int month, int day) {
        for (ZodiacSign sign : values()) {
            if (isDateInRange(month, day, sign)) {
                return sign;
            }
        }
        return CAPRICORN; // 기본값
    }

    private static boolean isDateInRange(int month, int day, ZodiacSign sign) {
        // 연말연초를 걸치는 염소자리 처리
        if (sign == CAPRICORN) {
            return (month == 12 && day >= 22) || (month == 1 && day <= 19);
        }

        if (sign.startMonth == sign.endMonth) {
            return month == sign.startMonth && day >= sign.startDay && day <= sign.endDay;
        } else {
            return (month == sign.startMonth && day >= sign.startDay) ||
                   (month == sign.endMonth && day <= sign.endDay);
        }
    }
}