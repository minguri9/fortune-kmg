package com.fortune.fortune.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "fortunes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fortune {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ZodiacSign zodiacSign;

    @Column(nullable = false)
    private LocalDate fortuneDate;

    @Column(columnDefinition = "TEXT")
    private String generalFortune; // 전체 운세

    @Column(columnDefinition = "TEXT")
    private String loveFortune; // 사랑 운세

    @Column(columnDefinition = "TEXT")
    private String moneyFortune; // 금전 운세

    @Column(columnDefinition = "TEXT")
    private String healthFortune; // 건강 운세

    @Column
    private Integer luckyNumber; // 행운의 숫자

    @Column(length = 20)
    private String luckyColor; // 행운의 색깔

    @Column(length = 100)
    private String luckyItem; // 행운의 아이템

    @Column
    private Integer overallScore; // 전체 운세 점수 (1-100)

    @Column
    private Integer loveScore; // 애정운 점수 (1-100)

    @Column
    private Integer moneyScore; // 금전운 점수 (1-100)

    @Column
    private Integer healthScore; // 건강운 점수 (1-100)

}