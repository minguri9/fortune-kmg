package com.fortune.fortune.entity;

import lombok.Getter;

@Getter
public enum ZodiacSign {
    ARIES("양자리", "3월 21일 ~ 4월 19일", 3, 21, 4, 19),
    TAURUS("황소자리", "4월 20일 ~ 5월 20일", 4, 20, 5, 20),
    GEMINI("쌍둥이자리", "5월 21일 ~ 6월 21일", 5, 21, 6, 21),
    CANCER("게자리", "6월 22일 ~ 7월 22일", 6, 22, 7, 22),
    LEO("사자자리", "7월 23일 ~ 8월 22일", 7, 23, 8, 22),
    VIRGO("처녀자리", "8월 23일 ~ 9월 22일", 8, 23, 9, 22),
    LIBRA("천칭자리", "9월 23일 ~ 10월 22일", 9, 23, 10, 22),
    SCORPIO("전갈자리", "10월 23일 ~ 11월 21일", 10, 23, 11, 21),
    SAGITTARIUS("사수자리", "11월 22일 ~ 12월 21일", 11, 22, 12, 21),
    CAPRICORN("염소자리", "12월 22일 ~ 1월 19일", 12, 22, 1, 19),
    AQUARIUS("물병자리", "1월 20일 ~ 2월 18일", 1, 20, 2, 18),
    PISCES("물고기자리", "2월 19일 ~ 3월 20일", 2, 19, 3, 20);

    private final String koreanName;
    private final String period;
    private final int startMonth;
    private final int startDay;
    private final int endMonth;
    private final int endDay;

    ZodiacSign(String koreanName, String period, int startMonth, int startDay, int endMonth, int endDay) {
        this.koreanName = koreanName;
        this.period = period;
        this.startMonth = startMonth;
        this.startDay = startDay;
        this.endMonth = endMonth;
        this.endDay = endDay;
    }

    public static ZodiacSign fromBirthDate(int month, int day) {
        for (ZodiacSign sign : values()) {
            if (isDateInRange(month, day, sign)) {
                return sign;
            }
        }
        return CAPRICORN; // 기본값
    }

    private static boolean isDateInRange(int month, int day, ZodiacSign sign) {
        // 연말연초를 걸치는 염소자리 처리
        if (sign == CAPRICORN) {
            return (month == 12 && day >= 22) || (month == 1 && day <= 19);
        }

        if (sign.startMonth == sign.endMonth) {
            return month == sign.startMonth && day >= sign.startDay && day <= sign.endDay;
        } else {
            return (month == sign.startMonth && day >= sign.startDay) ||
                   (month == sign.endMonth && day <= sign.endDay);
        }
    }
}