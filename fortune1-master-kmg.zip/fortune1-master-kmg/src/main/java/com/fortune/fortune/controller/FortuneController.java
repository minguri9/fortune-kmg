package com.fortune.fortune.controller;

import com.fortune.fortune.entity.Fortune;
import com.fortune.fortune.entity.ZodiacSign;
import com.fortune.fortune.service.FortuneService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Controller
@RequiredArgsConstructor
public class FortuneController {

    private final FortuneService fortuneService;

    // 메인 페이지
    @GetMapping("/")
    public String index() {
        return "index";
    }

    // 운세 조회 처리
    @PostMapping("/fortune")
    public String getFortune(@RequestParam("gender") String gender,
                             @RequestParam("calendarType") String calendarType,
                             @RequestParam("bornTime") String bornTime,
                             @RequestParam("userName") String userName,
                             @RequestParam("birthDate") String birthDateStr,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        LocalDate birthDate = LocalDate.parse(birthDateStr);
        int birthYear = birthDate.getYear();

        Fortune fortune = fortuneService.getFortuneForUser(userName, birthDate);

        try {
            // 날짜 파싱
            birthDate = LocalDate.parse(birthDateStr);

            // 미래 날짜 체크
            if (birthDate.isAfter(LocalDate.now())) {
                redirectAttributes.addFlashAttribute("error", "올바른 생년월일을 입력해주세요.");
                return "redirect:/";
            }


        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "올바른 날짜 형식을 입력해주세요. (예: 1990-01-15)");
            return "redirect:/";
        }



        // 별자리 계산
        ZodiacSign zodiacSign = fortuneService.calculateZodiacSign(birthDate);

        // 날짜 계산
        LocalDate today = LocalDate.now();

        // 오늘 운세(Fortune 엔티티)
        Fortune todayObj = fortuneService.generateFortune(zodiacSign, today, gender, calendarType, bornTime);


        LocalDate tomorrow = today.plusDays(1);
        LocalDate weekStart = today.with(DayOfWeek.MONDAY);
        LocalDate monthStart = today.withDayOfMonth(1);



        Fortune tomorrowObj = fortuneService.generateFortune(zodiacSign, tomorrow, gender, calendarType, bornTime);
        Fortune weekObj = fortuneService.generateFortune(zodiacSign, weekStart, gender, calendarType, bornTime);
        Fortune monthObj = fortuneService.generateFortune(zodiacSign, monthStart, gender, calendarType, bornTime);

        // 텍스트 운세
        String todayFortune = fortuneService.getDailyFortune(birthDate, today);
        String tomorrowFortune = fortuneService.getDailyFortune(birthDate, tomorrow);
        String weekFortune = fortuneService.getRangeFortune(birthDate, weekStart, weekStart.plusDays(6));
        String monthFortune = fortuneService.getRangeFortune(birthDate, monthStart, monthStart.withDayOfMonth(monthStart.lengthOfMonth()));


        String ddiddi = fortuneService.getDdiddi(birthYear) + "띠";
        String ddiddimap = fortuneService.getDdiddi(birthYear);
        String ddiddiYears = fortuneService.getDdiddiYears(ddiddi);


        // 모델 전달
        model.addAttribute("userName", userName);
        model.addAttribute("birthDate", birthDate.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일")));
        model.addAttribute("zodiacSign", zodiacSign);

        // 문자 운세
        model.addAttribute("todayFortune", todayFortune);
        model.addAttribute("tomorrowFortune", tomorrowFortune);
        model.addAttribute("weekFortune", weekFortune);
        model.addAttribute("monthFortune", monthFortune);

        model.addAttribute("ddiddi", ddiddi);
        model.addAttribute("ddiddimap", ddiddimap);
        model.addAttribute("ddiddiYears", ddiddiYears);

        // 객체 운세(상세지수·페르소나·행운템)
        model.addAttribute("todayObj", todayObj);
        model.addAttribute("tomorrowObj", tomorrowObj);
        model.addAttribute("weekObj", weekObj);
        model.addAttribute("monthObj", monthObj);

        model.addAttribute("gender", gender);
        model.addAttribute("calendarType", calendarType);
        model.addAttribute("bornTime", bornTime);




        return "fortune-result";



    }



    // 별자리별 운세 보기
    @GetMapping("/zodiac")
    public String getZodiacFortune(@RequestParam("sign") String signName, Model model) {
        try {
            ZodiacSign zodiacSign = ZodiacSign.valueOf(signName.toUpperCase());
            Fortune fortune = fortuneService.getTodayFortune(zodiacSign);

            model.addAttribute("zodiacSign", zodiacSign);
            model.addAttribute("fortune", fortune);

            return "zodiac-fortune";

        } catch (IllegalArgumentException e) {
            return "redirect:/";
        }
    }

    // 모든 별자리 보기
    @GetMapping("/all-zodiacs")
    public String getAllZodiacs(Model model) {
        model.addAttribute("zodiacSigns", ZodiacSign.values());
        return "all-zodiacs";
    }

    // ⭐ 타로 페이지 이동
    @GetMapping("/tarot")
    public String tarot() {
        return "tarot";
    }

    // ⭐ 타로 카드 목록
    private final List<String> tarotNames = List.of(
            "The Fool (바보)",
            "The Magician (마법사)",
            "The High Priestess (여사제)",
            "The Empress (여황제)",
            "The Emperor (황제)",
            "The Lovers (연인)",
            "The Chariot (전차)",
            "Strength (힘)",
            "The Hermit (은둔자)",
            "Wheel of Fortune (운명의 수레바퀴)",
            "Justice (정의)",
            "The Hanged Man (매달린 사람)",
            "Death (죽음)",
            "Temperance (절제)",
            "The Devil (악마)",
            "The Tower (탑)",
            "The Star (별)",
            "The Moon (달)",
            "The Sun (태양)",
            "Judgement (심판)",
            "The World (세계)"


    );

    //정방향 리스트
    private final List<String> tarotUpright = List.of(
            /*바보*/"새로운 시작, 모험, 자유로운 에너지.\n오늘은 도전이 행운을 가져옵니다.",
            /*마법사*/"성취, 능력, 기회.\n원하는 목표를 이룰 수 있는 날!",
            /*여사제*/"직감, 내면의 지혜, 신중함.\n속마음을 믿으세요.",
            /*여황제*/"풍요, 창조, 사랑.\n따뜻한 기운이 주변을 감쌉니다.",
            /*황제*/"안정, 리더십, 통제.\n당당한 태도가 기회를 만들어요.",
            /*교황*/"사랑, 관계, 소울메이트.\n감정적인 연결이 깊어집니다.",
            /*연인*/"승리, 추진력, 강한 의지.\n계획이 술술 풀립니다!",
            /*전차*/"용기, 자신감, 회복.\n두려움을 넘어설 수 있는 날.",
            /*힘*/"분석, 휴식, 깊은 성찰.\n혼자만의 시간이 행운을 줍니다.",
            /*은둔자*/"행운, 변화, 좋은 흐름.\n운명이 당신을 돕고 있어요.",
            /*운명의 수레바퀴*/"균형, 공정함, 올바른 선택.\n오늘은 당신의 판단이 상황을 더 나은 방향으로 이끕니다.",
            /*정의*/"균형, 공정함, 올바른 선택.\n오늘은 당신의 판단이 상황을 더 나은 방향으로 이끕니다.",
            /*매달린 사람*/"새로운 관점, 인내, 내려놓음.\n멈춰서 생각하면 해결책이 보입니다.",
            /*죽음*/"끝과 시작, 변화, 전환점.\n무언가 마무리되고 새로운 길이 열립니다.",
            /*절제*/"조화, 균형, 조절.\n무리하지 않고 천천히 조율하는 것이 행운입니다.",
            /*악마*/"유혹, 집착, 충동.\n오늘은 감정적인 선택에 주의가 필요합니다.",
            /*탑*/"갑작스러운 변화, 깨달음, 재정비.\n예상치 못한 일이 생길 수 있습니다.",
            /*별*/"희망, 영감, 회복.\n당신의 바람이 긍정적인 방향으로 흐르고 있습니다.",
            /*달*/"불확실성, 감정, 직감.\n겉으로 보이는 것만 믿지 마세요.",
            /*태양*/"성공, 기쁨, 긍정.\n문제가 해결되고 좋은 소식이 찾아옵니다.",
            /*심판*/"각성, 결단, 새로운 기회.\n중요한 결정을 내려야 하는 순간입니다.",
            /*세계*/"완성, 성취, 완벽한 조화.\n그동안의 노력이 결실을 맺습니다."
    );

    //역방향 리스트
    private final List<String> tarotReversed = List.of(
            "불안, 준비 부족.\n성급하게 나서면 오히려 흐름이 막힐 수 있습니다.",
            "집중력 부족 또는 방향성 혼란.\n잠시 멈추고 목표를 재정비하세요.",
            "혼란, 감정적 불안.\n직감이 흐려질 수 있으니 섣부른 판단은 피하세요.",
            "과한 감정 또는 의존.\n균형을 유지해야 합니다.",
            "고집, 통제력 부족.\n융통성을 가지면 해결됩니다.",
            "관계 불균형.\n감정적으로 예민해질 수 있으니 차분히 대화하세요.",
            "지침, 추진력 저하.\n과한 무리가 문제를 만들 수 있습니다.",
            "자신감 부족.\n그러나 잠시 쉬면 에너지가 회복됩니다.",
            "고립, 지나친 고민.\n누군가에게 털어놓으면 해결됩니다.",
            "고착된 흐름, 작은 불운.\n하지만 오래 지속되지는 않습니다.",
            "불공정한 상황.\n서두르지 않고 사실을 확인하세요.",
            "정체, 희생 강요.\n지금은 움직일 때가 아닐 수 있습니다.",
            "종결되지 않은 문제.\n미뤄둔 일의 해결이 필요합니다.",
            "불균형, 과도함.\n속도를 줄이고 조절하세요.",
            "유혹에 휘둘림, 나쁜 습관.\n경계를 유지하세요.",
            "충격, 예상 못한 방해.\n하지만 이 과정이 새로운 길을 엽니다.",
            "희망 상실.\n하지만 작은 조짐을 놓치지 마세요.",
            "혼란, 오해.\n진실이 드러날 때까지 기다리세요.",
            "지연, 작은 방해.\n하지만 전체 흐름은 여전히 긍정적입니다.",
            "미뤄진 결단.\n속도를 조절해야 할 때입니다.",
            "미완성, 지연.\n조금만 더 힘을 내면 완성됩니다."
    );

    // ⭐ 타로 뽑기 결과 처리
    @PostMapping("/tarot-result")
    public String tarotResult(Model model) {
        Random random = new Random();
        int index = random.nextInt(tarotNames.size());

        boolean reversed = random.nextBoolean(); // true -> 역방향

        model.addAttribute("tarotName", tarotNames.get(index));
        model.addAttribute("direction", reversed ? "역방향(Reversed)" : "정방향(Upright)");
        model.addAttribute("tarotMeaning", reversed ? tarotReversed.get(index) : tarotUpright.get(index));

        // ⭐ 이미지 파일 번호 전달
        model.addAttribute("tarotImage", index);
        model.addAttribute("isReversed", reversed);

        return "tarot-result";
    }

    @GetMapping("/tarot-loading")
    public String tarotLoading() {
        return "tarot-loading";
    }

    @PostMapping("/tarot-go")
    public String tarotGo() {
        return "tarot-loading";
    }

    @GetMapping("/tarot-result")
    public String tarotResultGet(Model model) {
        return tarotResult(model);
    }

    private final List<String> tarotDeepUpright = List.of(
            "새로운 여정의 문턱에 섰습니다.\n" +
                    "당신은 지금 과거의 부담에서 벗어나 자유롭게 나아갈 준비가 되어 있습니다.\n" +
                    "두려움보다 호기심이 더 크고, 그 감정이 당신을 올바른 길로 이끌 것입니다.\n" +
                    "다만 준비되지 않은 채 성급히 뛰어드는 것은 위험할 수 있습니다.\n" +
                    "순수한 마음으로 움직이되, 주변의 조언도 귀 기울여 보세요.",
            "당신은 지금 자신의 능력을 가장 잘 활용할 수 있는 시점에 있습니다.\n" +
                    "아이디어가 현실이 되고, 당신의 의지가 실제 성과로 이어집니다.\n" +
                    "삶을 변화시킬 수 있는 힘이 이미 손 안에 있으며,\n" +
                    "집중만 한다면 원하는 바를 정확히 이루어낼 수 있습니다.\n" +
                    "자신감을 가지고 주도권을 잡으세요.",
            "겉으로 드러나지 않은 사실이 당신의 선택을 좌우합니다.\n" +
                    "지금 가장 중요한 것은 이성적 판단보다 ‘직감’입니다.\n" +
                    "마음속 깊은 곳에서 들리는 작은 목소리에 귀 기울이세요.\n" +
                    "지금 드러나지 않은 비밀과 진실이 곧 모습을 드러낼 것입니다.\n" +
                    "침착하게 흐름을 지켜보는 것이 최선입니다.",
            "당신의 삶에 풍요와 따뜻한 에너지가 스며들고 있습니다.\n" +
                    "사랑과 감정이 안정되고, 관계가 더 깊어질 수 있습니다.\n" +
                    "창의력 또한 높아져 새로운 아이디어나 작품 활동에 매우 유리합니다.\n" +
                    "자신을 돌보는 시간을 가지면 더 큰 행운이 따라올 것입니다.",
            "당신의 의지와 질서, 규칙성이 큰 힘을 발휘하는 시점입니다.\n" +
                    "결단력 있고 강한 태도가 상황을 안정적으로 만들어 줍니다.\n" +
                    "책임감 있는 자세가 요구되며, 누군가 당신에게 기대고 의지하게 됩니다.\n" +
                    "감정보다 ‘원칙’을 우선한다면 승리할 것입니다.",
            "전통적인 방법, 안정적인 조언이 큰 도움이 됩니다.\n" +
                    "누군가에게서 지혜를 얻거나 누군가에게 조언을 건네는 역할을 할 수도 있습니다.\n" +
                    "예의와 규범을 지키는 것이 행운으로 이어집니다.\n" +
                    "섣부른 모험보다 경험 많은 사람의 말을 따르세요.",
            "당신에게 중요한 ‘선택’이 다가오고 있습니다.\n" +
                    "이는 사랑, 관계, 감정적인 부분과 밀접한 연관이 있습니다.\n" +
                    "진심을 따르는 것이 가장 좋은 결과를 만듭니다.\n" +
                    "무엇보다 자기 자신과의 조화를 이루는 것이 우선입니다.",
            "앞으로 나아갈 강력한 추진력이 생기는 시점입니다.\n" +
                    "당신의 의지와 노력은 곧 빠른 성과로 이어집니다.\n" +
                    "지금은 멈추지 말고 앞으로 달려가야 할 때입니다.\n" +
                    "스스로에 대한 확신이 승리를 가져옵니다.",
            "당신은 지금 강한 내적 힘을 지니고 있습니다.\n" +
                    "이 힘은 공격적인 성향이 아니라, 부드럽고 친절한 용기입니다.\n" +
                    "자신의 감정을 다스릴 수 있고, 이를 통해 문제를 해결하게 됩니다.\n" +
                    "어떤 상황에서도 흔들리지 않는 마음이 필요합니다.",
            "잠시 혼자만의 시간을 가지는 것이 큰 도움을 줍니다.\n" +
                    "바쁘게 움직이기보다는 잠시 멈춰 진지하게 생각해보세요.\n" +
                    "내면의 답을 찾는 시기이며, 진정한 자기 이해의 시간이 될 것입니다.\n" +
                    "단순한 고독이 아니라 ‘성찰’이 필요한 때입니다.",
            "당신의 인생이 새로운 흐름을 맞이하고 있습니다.\n" +
                    "좋은 변화가 찾아올 가능성이 매우 높습니다.\n" +
                    "운명이 새로운 기회를 가져다주고 있으며,\n" +
                    "그 흐름을 받아들이기만 해도 상황이 개선됩니다.\n" +
                    "지금은 운의 흐름에 올라타면 됩니다.",
            "당신의 선택과 행동이 곧 결과를 만들어냅니다.\n" +
                    "지금은 공정함과 균형이 무엇보다 중요합니다.\n" +
                    "그동안 해왔던 행동의 결과가 돌아오는 시기이므로\n" +
                    "정직하고 올바른 태도가 최고의 결과를 낳습니다.\n" +
                    "법적·행정적 문제에서도 유리한 흐름입니다.",
            "당장은 진전이 없는 것처럼 느껴질 수 있지만\n" +
                    "그 속에서 새로운 시각과 해답을 발견할 수 있습니다.\n" +
                    "희생처럼 느껴지는 시간이 곧 더 큰 성장을 가져옵니다.\n" +
                    "서두르지 말고, 잠시 삶의 흐름을 믿어보세요.",
            "무언가가 끝나고 새로운 무언가가 시작됩니다.\n" +
                    "이 변화는 두려울 수 있지만 결국 더 나은 방향으로 이어질 것입니다.\n" +
                    "낡은 습관, 관계, 감정 등을 놓아줄 때가 되었습니다.\n" +
                    "새로운 가능성이 이미 문 앞에 와 있습니다.",
            "균형과 조화가 당신의 운을 결정합니다.\n" +
                    "무언가를 지나치게 하거나 과도하게 억누르지 말고\n" +
                    "천천히 흐름을 맞추는 자세가 필요합니다.\n" +
                    "겉으로 보기엔 느려 보여도, 가장 좋은 결과로 이어집니다.",
            "당신의 마음을 흔드는 유혹이나 집착이 있을 수 있습니다.\n" +
                    "이것이 꼭 나쁜 결과를 의미하는 것은 아니지만\n" +
                    "감정적 충동에 휘둘리면 후회할 수 있습니다.\n" +
                    "스스로를 속박하는 것이 무엇인지 돌아보세요.\n" +
                    "그것을 인식하는 것만으로도 이미 절반은 풀립니다.",
            "갑작스럽고 충격적인 변화가 일어날 수 있습니다.\n" +
                    "하지만 이 변화는 오래된 구조를 무너뜨리고\n" +
                    "새로운 길을 만들기 위한 필수적인 과정입니다.\n" +
                    "힘들어 보여도, 끝내 더 안정된 미래를 위해 필요한 사건입니다.",
            "당신의 삶에 희망과 영감이 깃듭니다.\n" +
                    "지금의 소망이 현실로 이어질 가능성이 높습니다.\n" +
                    "어둠 이후 드디어 빛이 드러나는 시점이며\n" +
                    "치유의 에너지가 당신을 감싸고 있습니다.\n" +
                    "마음껏 꿈꿔도 좋은 날입니다.",
            "감정이 복잡해지고 불확실한 상황이 많아질 수 있습니다.\n" +
                    "그러나 이는 모든 것이 흐릿해지는 것이 아니라\n" +
                    "숨겨진 진실을 볼 수 있는 기회가 주어지는 것입니다.\n" +
                    "직감은 날카롭지만, 상상과 현실을 구분하는 것이 필요합니다.",
            "명확한 성공, 기쁨, 좋은 소식이 다가옵니다.\n" +
                    "당신을 둘러싼 모든 에너지가 밝고 따뜻합니다.\n" +
                    "계획했던 일들이 탄탄하게 진행되고\n" +
                    "긍정적인 기운이 상황을 크게 밀어줍니다.\n" +
                    "행운의 절정이라고 할 수 있습니다.",
            "당신의 과거 경험이 현재를 변화시키는 중요한 역할을 합니다.\n" +
                    "중요한 선택의 순간이며 새로운 기회가 재탄생처럼 주어집니다.\n" +
                    "이 시기는 ‘결심’이 결과를 바꾸는 시점입니다.\n" +
                    "과거의 잘못을 바로잡고 새 출발을 할 수 있습니다.",
            "당신은 지금 하나의 큰 사이클을 완성하고 있습니다.\n" +
                    "그동안의 노력과 과정이 결실을 맺으며 성취를 이룹니다.\n" +
                    "이루고자 했던 목표가 완성되고\n" +
                    "삶이 하나로 자연스럽게 이어지는 느낌을 받을 것입니다.\n" +
                    "새로운 단계로 나아갈 준비가 된 증거입니다."
    );
    private final List<String> tarotDeepReversed = List.of(
            "불안정하거나 준비되지 않은 상태에서 성급하게 움직일 수 있습니다.\n" +
                    "새로운 시작이 꼭 나쁜 것은 아니지만, 지금은 충동보다는 신중함이 필요합니다.\n" +
                    "당신이 놓치고 있는 위험 요소가 숨어 있을 수 있으니\n" +
                    "계획을 점검한 뒤 다시 출발하는 것이 좋습니다.",
            "집중력 부족 또는 목표가 흐려질 수 있습니다.\n" +
                    "마음은 있는데 방향성이 맞지 않아 에너지가 분산되는 시기입니다.\n" +
                    "기술이나 능력 자체는 충분하나 ‘어디에 쓸 것인지’ 명확히 할 필요가 있습니다.\n" +
                    "자신을 의심하기보다 다시 중심을 잡는 시간을 가져보세요.",
            "감정적 혼란이나 직감의 혼선이 생길 수 있습니다.\n" +
                    "겉으로 보이는 것이 사실처럼 느껴질 수 있지만\n" +
                    "속마음이 흐려져 오해가 커질 수 있는 시점입니다.\n" +
                    "서두르지 말고 상황을 조금 더 관찰하세요.",
            "과한 감정 소비나 타인에게 의존하는 경향이 생길 수 있습니다.\n" +
                    "풍요가 막히는 것이 아니라 ‘흐름이 잠시 정체되는 시기’입니다.\n" +
                    "자기 돌봄을 게을리하면 기운이 쉽게 소모됩니다.\n" +
                    "스스로에게 휴식과 온기를 주세요.",
            "고집이나 통제가 지나쳐 갈등이 생길 수 있습니다.\n" +
                    "당신의 의지 자체는 좋지만 ‘방식’이 너무 딱딱해질 수 있습니다.\n" +
                    "상대의 의견을 조금만 수용해도 상황이 부드럽게 풀립니다.\n" +
                    "융통성이 곧 행운입니다.",
            "전통적인 방식이나 기존의 조언이 잘 맞지 않는 시기입니다.\n" +
                    "누군가의 말보다 스스로의 판단이 더 중요할 수 있습니다.\n" +
                    "답은 익숙한 곳이 아니라 새로운 방식에서 나타날 수 있습니다.\n" +
                    "부드럽게 기준을 재정립해보세요.",
            "감정적 충돌이나 선택의 혼란이 생길 수 있습니다.\n" +
                    "무언가 확신이 서지 않는다면 지금은 결정을 미루는 것이 좋습니다.\n" +
                    "현재의 감정이 진짜인지, 순간적인 감정인지 구분해야 합니다.\n" +
                    "자기 마음을 먼저 정리하세요.",
            "추진력 저하 또는 방향성 잃음이 나타날 수 있습니다.\n" +
                    "당신의 의지가 약해진 것이 아니라 ‘잠시 멈춤’이 필요한 시기입니다.\n" +
                    "계획을 다시 정비하면 흐름이 다시 강해집니다.\n" +
                    "속도를 조절하세요.",
            "자신감 부족이나 감정 조절 어려움이 있을 수 있습니다.\n" +
                    "힘이 없는 게 아니라, 에너지가 분산된 상태일 뿐입니다.\n" +
                    "누군가에게 기대거나 조언을 받는 것이 회복에 큰 도움이 됩니다.\n" +
                    "당신은 충분히 강합니다.",
            "과도한 고립이나 지나친 고민으로 길을 잃을 수 있습니다.\n" +
                    "혼자 있는 시간 자체는 좋지만 지금은 타인의 시각도 필요합니다.\n" +
                    "누군가에게 털어놓는 것만으로도 답이 보일 수 있습니다.",
            "흐름이 막히거나 작은 불운이 올 수 있지만 오래 가지 않습니다.\n" +
                    "운이 나쁜 것이 아니라, 타이밍이 맞지 않는 정도입니다.\n" +
                    "다시 기회를 잡을 수 있으니 포기하지 마세요.\n" +
                    "조금만 기다리면 운이 다시 흐릅니다.",
            "불공정한 상황이나 오해가 생길 수 있습니다.\n" +
                    "하지만 시간이 지나면 진실이 드러납니다.\n" +
                    "성급히 판단하면 상황이 복잡해질 수 있으니sss 차분히 증거를 모아보세요.",
            "정체됨, 희생의 강요, 의미 없는 기다림이 될 수 있습니다.\n" +
                    "지금은 멈춰선 것이 아니라 ‘발전 없는 멈춤’일 수 있으므로\n" +
                    "관점을 바꿀 필요가 있습니다.\n" +
                    "새로운 선택이 필요합니다.",
            "종료되어야 할 일이 끝나지 않고 계속 이어질 수 있습니다.\n" +
                    "미련이나 두려움 때문에 놓지 못하는 것일 수도 있습니다.\n" +
                    "하지만 붙잡고 있을수록 더 크게 지칩니다.\n" +
                    "과감히 정리하면 좋은 새로운 시작이 열립니다.",
            "균형이 무너지고 과하거나 부족한 상태가 될 수 있습니다.\n" +
                    "감정적 반응이 커져 주변과 충돌할 수 있는 시점입니다.\n" +
                    "속도를 줄이고 스스로를 조절하는 것이 무엇보다 중요합니다.\n" +
                    "다시 조율하면 금방 안정됩니다.",
            "집착·유혹·중독에서 벗어날 기회가 주어집니다.\n" +
                    "당신을 묶어두던 감정이나 습관에서 벗어나기 시작합니다.\n" +
                    "이제는 스스로를 감시하는 것이 아니라 해방하는 방향으로 움직여야 합니다.\n" +
                    "해방의 기운이 강하게 작용합니다.",
            "예상된 변화, 피할 수 없는 충격이지만\n" +
                    "정방향보다 훨씬 약하게 작용합니다.\n" +
                    "큰 위기가 아니라 ‘경고성 변화’ 정도로 나타날 수 있습니다.\n" +
                    "지금 미세하게 조정하면 큰 붕괴는 피해갈 수 있습니다.",
            "희망이 보이지 않는 듯 느껴질 수 있지만\n" +
                    "완전히 사라진 것이 아니라 잠시 흐릿해진 것뿐입니다.\n" +
                    "스스로를 의심하는 마음이 더 큰 문제입니다.\n" +
                    "조금만 마음을 다잡으면 다시 빛을 찾을 것입니다.",
            "혼란이 점차 걷히기 시작합니다.\n" +
                    "숨겨져 있던 진실이 드러나며\n" +
                    "당신을 괴롭히던 오해나 감정적 불안이 정리됩니다.\n" +
                    "상황을 제대로 보기 시작하는 시기입니다.",
            "성공이 약간 지연되거나 작은 방해가 있을 수 있습니다.\n" +
                    "행운이 사라진 것이 아니라 ‘속도가 느려진 것’뿐입니다.\n" +
                    "조금 더 세밀한 점검이 필요합니다.\n" +
                    "곧 다시 밝아질 것입니다.",
            "중요한 결정을 미루거나 기회를 놓칠 수 있는 시기입니다.\n" +
                    "또는 과거 문제를 반복하지 않으려는 두려움이 있을 수 있습니다.\n" +
                    "하지만 결단을 내리면 큰 변화가 일어나니\n" +
                    "지금은 용기가 필요합니다.",
            "마무리가 되지 않은 일, 미완성, 지연을 뜻합니다.\n" +
                    "진짜 끝낼 단계인데 마지막 한 걸음이 부족한 상태입니다.\n" +
                    "포기하기엔 너무 많이 와 있습니다.\n" +
                    "조금만 더 힘을 내면 완전한 완성과 성취를 얻을 수 있습니다."
    );


    @GetMapping("/tarot-detail/{id}/{reversed}")
    public String tarotDetail(@PathVariable int id,
                              @PathVariable boolean reversed,
                              Model model) {

        model.addAttribute("tarotName", tarotNames.get(id));
        model.addAttribute("direction", reversed ? "역방향(Reversed)" : "정방향(Upright)");
        model.addAttribute("image", id + ".png");
        model.addAttribute("deepMeaning", reversed ? tarotDeepReversed.get(id) : tarotDeepUpright.get(id));

        return "tarot-detail";
    }

    @GetMapping("/fortune-cookie")
    @ResponseBody
    public String fortuneCookie() {
        List<String> messages = Arrays.asList(
                "행운이 당신을 향해 달려오고 있어요.",
                "오늘의 노력은 곧 결실을 맺습니다.",
                "기회는 당신의 편입니다.",
                "좋은 일이 생길 조짐이 보여요.",
                "오늘은 당신에게 유리한 날입니다.",
                "작은 선택이 큰 결과를 가져옵니다."
        );

        return messages.get(new Random().nextInt(messages.size()));
    }

}